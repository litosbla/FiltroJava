package com.campusland.respository.models;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.campusland.utils.Formato;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class Descuento {
    private int numeroDescuento;
  
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    public enum TipoDescuentoEnum {
        PORCENTAJE,
        VALOR;
    }
    private String descripcion;
    private double montovalor;
    private List<Cliente> cliente;
    private List<ItemFactura> items;
    private enum TipoEstado{
        ACTIVO,
        INACTIVO;
    };
    private static int nextNumeroDescuento;
    public Descuento(){

    }
    public Descuento(int numeroDescuento, String descripcion, double montovalor, List<Cliente> cliente,
            List<ItemFactura> items) {
        this.numeroDescuento = numeroDescuento;
        this.descripcion = descripcion;
        this.montovalor = montovalor;
        this.cliente = new ArrayList<>();
        this.items = new ArrayList<>();
    }
    
    public void agregarProductos(ItemFactura item){
        this.items.add(item);
    }
}
