package com.campusland.exceptiones.facturaexceptions;

public class FacturaExceptionInsertDataBase extends FacturaException {

    public FacturaExceptionInsertDataBase(String mensaje) {
        super(mensaje);
        
    }
    
}
